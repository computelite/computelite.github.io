#!/usr/bin/env python3

import apsw.shell

apsw.shell.main()